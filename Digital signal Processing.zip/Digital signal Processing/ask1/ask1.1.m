
F = pi/90 %rythmos deigmatolhpsias
x1 = [0 : F : 4*pi ]; %times tou aksona X
y1 = cos(x1);  %times aksona Y
figure(1);
plot(x1,y1);
grid;
title('Cosine');
xlabel('aksonas X'); %'?????? ?'
ylabel('aksonas Y'); %'?????? ?'

x2 = [ -2*pi : F : 2*pi ];  %times tou aksona X
y2 = sin(x2);    %times aksona Y
figure(2);
plot(x2,y2);
grid;
tittle('sine');
xlabel('aksonas X'); %'?????? ?'
ylabel('aksonas Y'); %'?????? ?'