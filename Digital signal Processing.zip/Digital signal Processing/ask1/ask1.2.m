

F=pi/90;         %rythmos deigmatolhpsias

x1=[0:F:4*pi];   %times tou aksona X
y1=cos(x1);      %times aksona Y

x2=[-2*pi:F:2*pi];  %times tou aksona X
y2=sin(x2);         %times aksona Y

figure(1)
subplot(2,1,1)      %2 lines , 1 row , drawing a Cf on the 1st position 
plot(x1,y1,'r')
grid 
title('cosine')
xlabel('aksonas x') %'?????? ?'
ylabel('aksonas y')  %'?????? ?'


subplot(2,1,2)      %2 lines , 1 row , drawing a Cf on the 2nd position
plot(x2,y2)
title('sine')
xlabel('aksonas x') %'?????? ?'
ylabel('aksonas y')  %'?????? ?'
grid
