
ts = 1/150;
t = 0:1/50000:2*ts;

x = 6-2*cos(600*pi*t)+6*cos(1200*pi*t)+6*cos(1500*pi*t)-0,5*cos(6000*pi*t);

plot(t,x);
xlabel('x')
ylabel('y')

Fs = 7000;
ts2 = 1/Fs;
t2 = 0:ts2:93*ts2;
x2 = 6-2*cos(600*pi*t2)+6*cos(1200*pi*t2)+6*cos(1500*pi*t2)-0,5*cos(6000*pi*t2);
hold on;
plot(t2,x2,'ro-');
xlabel('x')
ylabel('y')