x = [-1,0,1,2,4,5,4,-5,-8,-9];
y = conv(x,h);
figure(1);
plot(y);
xlabel('x')
ylabel('y')

%3

y2 = filter(b,a,x);
hold on;
plot(y2,'r');