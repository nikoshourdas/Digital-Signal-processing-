
a = [1 0 0.1 0 0.06 0];
b = [0.2 0.5 0 0 0 0.4];

figure(1);
freqz(b,a);
xlabel('b')
ylabel('a')