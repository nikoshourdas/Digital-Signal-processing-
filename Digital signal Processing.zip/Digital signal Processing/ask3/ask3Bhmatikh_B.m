
n = 0:100 ; 
u = inline('n>=0');

a = [1 0 0.6];
b = [0.32 0.68 0.4];

y = filter(b,a,u(n));

figure(1)
stem(n,y)

title('Bhmatikh Apokrish B tropos');
xlabel('aksonas n');
ylabel('aksonas Y');

