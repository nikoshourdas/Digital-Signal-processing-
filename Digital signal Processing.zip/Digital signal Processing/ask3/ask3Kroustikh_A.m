

d = inline('n==0');

h(1) = 1 ; 

for n =2 :100 ;
    h(n) = 0.32 *d(n) + 0.68* d(n-1) + 0.4 *d(n-2) - 0.6 *h(n-2) ;
    
end 

stem(0:100:h);
title('Kroustikh Apokrish A tropos ')  
xlabel('aksonas n');                  				  %????? ????? ? 
ylabel('aksonas h');                  		  	  %????? ????? y