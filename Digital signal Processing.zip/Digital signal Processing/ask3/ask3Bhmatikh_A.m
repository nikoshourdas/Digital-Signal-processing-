n = 0:100 ; 
s = zeros(1,length(n));
u = inline('n>=0');


s(1) = 1 ;

for i=3:length(n)                              	 
 s(i)=0.32*u(n(i)) + 0.68*u(n(i)-1) + 0.4*u(n(i)-2) - 0.6*s(i-2);  
end 

figure(1);
stem(n,s);
title('Bhmatikh Apokrish A tropos');
xlabel('aksonas n');
ylabel('aksonas Y');
